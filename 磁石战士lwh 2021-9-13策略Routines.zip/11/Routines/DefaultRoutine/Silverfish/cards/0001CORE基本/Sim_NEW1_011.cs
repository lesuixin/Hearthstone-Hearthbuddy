using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_NEW1_011 : SimTemplate //* 库卡隆精英卫士 Kor'kron Elite
	{
		//<b>Charge</b>
		//<b>冲锋</b>
		
		
	}
}
