using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_HERO_02mbp : SimTemplate //* 图腾召唤 Totemic Call
	{
		//<b>Hero Power</b>Summon a random Totem.
		//<b>英雄技能</b>随机召唤一个图腾。
		
		
	}
}
