using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS2_171 : SimTemplate //* 石牙野猪 Stonetusk Boar
	{
		//<b>Charge</b>
		//<b>冲锋</b>
		
		
	}
}
