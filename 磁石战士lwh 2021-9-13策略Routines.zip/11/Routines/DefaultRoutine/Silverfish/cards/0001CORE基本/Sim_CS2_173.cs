using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS2_173 : SimTemplate //* 蓝鳃战士 Bluegill Warrior
	{
		//<b>Charge</b>
		//<b>冲锋</b>
		
		
	}
}
