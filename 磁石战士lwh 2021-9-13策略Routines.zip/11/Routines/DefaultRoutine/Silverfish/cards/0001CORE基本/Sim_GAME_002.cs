using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_GAME_002 : SimTemplate //* 幸运币化身 Avatar of the Coin
	{
		//<i>You lost the coin flip, but gained a friend.</i>
		//<i>你失去了先手，但比赛依然掌握在你的手里。</i>
		
		
	}
}
