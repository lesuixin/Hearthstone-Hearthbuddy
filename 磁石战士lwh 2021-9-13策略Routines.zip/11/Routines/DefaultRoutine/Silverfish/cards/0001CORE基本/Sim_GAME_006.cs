using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_GAME_006 : SimTemplate //* 不不不 NOOOOOOOOOOOO
	{
		//Somehow, the card you USED to have has been deleted.  Here, have this one instead!
		//出于某种原因，你曾经拥有的一张牌被删除了。拿着这张牌吧，它将成为那张牌的替代品！
		
		
	}
}
