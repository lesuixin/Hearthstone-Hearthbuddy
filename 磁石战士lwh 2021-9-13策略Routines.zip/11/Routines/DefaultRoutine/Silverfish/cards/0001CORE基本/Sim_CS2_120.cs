using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS2_120 : SimTemplate //* 淡水鳄 River Crocolisk
	{
		//
		//
		
		
	}
}
