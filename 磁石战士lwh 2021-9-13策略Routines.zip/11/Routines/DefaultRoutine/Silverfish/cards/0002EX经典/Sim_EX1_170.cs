using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_170 : SimTemplate //* 帝王眼镜蛇 Emperor Cobra
	{
		//<b>Poisonous</b>
		//<b>剧毒</b>
		
		
	}
}
