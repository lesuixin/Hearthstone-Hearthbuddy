using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_165t2 : SimTemplate //* 利爪德鲁伊 Druid of the Claw
	{
		//<b>Taunt</b>
		//<b>嘲讽</b>
		
		
	}
}
