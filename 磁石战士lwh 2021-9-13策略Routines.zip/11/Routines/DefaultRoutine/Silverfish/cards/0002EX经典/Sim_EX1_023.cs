using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_023 : SimTemplate //* 银月城卫兵 Silvermoon Guardian
	{
		//<b>Divine Shield</b>
		//<b>圣盾</b>
		
		
	}
}
