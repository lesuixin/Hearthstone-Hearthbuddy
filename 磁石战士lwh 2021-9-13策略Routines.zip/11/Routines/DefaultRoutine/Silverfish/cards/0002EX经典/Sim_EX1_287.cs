using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_287 : SimTemplate //* 法术反制 Counterspell
	{
		//<b>Secret:</b> When your opponent casts a spell, <b>Counter</b> it.
		//<b>奥秘：</b>当你的对手施放一个法术时，<b>反制</b>该法术。
		
		
	}
}
