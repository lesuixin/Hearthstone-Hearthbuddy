using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_180 : SimTemplate //* 智慧秘典 Tome of Intellect
	{
		//Add a random Mage spell to your hand.
		//随机将一张法师法术牌置入你的手牌。
		
		
	}
}
