using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_522 : SimTemplate //* 耐心的刺客 Patient Assassin
	{
		//<b>Stealth</b> <b>Poisonous</b>
		//<b>潜行</b><b>剧毒</b>
		
		
	}
}
