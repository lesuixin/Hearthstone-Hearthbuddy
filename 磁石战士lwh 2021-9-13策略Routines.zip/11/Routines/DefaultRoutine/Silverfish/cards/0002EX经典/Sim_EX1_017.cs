using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_017 : SimTemplate //* 丛林猎豹 Jungle Panther
	{
		//<b>Stealth</b>
		//<b>潜行</b>
		
		
	}
}
