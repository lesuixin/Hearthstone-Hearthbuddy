using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_181 : SimTemplate //* 虚空召唤 Call of the Void
	{
		//Add a random Demon to your hand.
		//随机将一张恶魔牌置入你的手牌。
		
		
	}
}
