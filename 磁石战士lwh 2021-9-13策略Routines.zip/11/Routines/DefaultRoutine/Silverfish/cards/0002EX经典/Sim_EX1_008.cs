using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_008 : SimTemplate //* 银色侍从 Argent Squire
	{
		//<b>Divine Shield</b>
		//<b>圣盾</b>
		
		
	}
}
